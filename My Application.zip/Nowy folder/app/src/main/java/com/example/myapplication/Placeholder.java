package com.example.myapplication;

import retrofit2.http.GET;

import java.util.List;

public class Placeholder {
    @GET("")
  public Call<List<Notatki>> get        ;
}